# 🎣 Fishing Competition App

React-based fishing competition tracker with local storage persistence.
