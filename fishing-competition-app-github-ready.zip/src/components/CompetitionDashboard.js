import { getCompetitions } from "../utils/db";

export default function CompetitionDashboard() {
  const competitions = getCompetitions();

  return (
    <div>
      <h2>Competition Dashboard</h2>
      {competitions.length === 0 ? (
        <p>No competitions created yet.</p>
      ) : (
        <ul>
          {competitions.map(c => (
            <li key={c.id}>
              <strong>{c.name}</strong> ({c.date})
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}