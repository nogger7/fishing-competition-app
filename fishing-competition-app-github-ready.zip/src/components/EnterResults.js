import { useState } from "react";
import { addResult, getCompetitions } from "../utils/db";

export default function EnterResults() {
  const competitions = getCompetitions();
  const [competitionId, setCompetitionId] = useState("");
  const [angler, setAngler] = useState("");
  const [fishWeight, setFishWeight] = useState("");

  const handleSubmit = e => {
    e.preventDefault();
    addResult(competitionId, { angler, fishWeight: parseFloat(fishWeight) });
    setAngler("");
    setFishWeight("");
    alert("Result added!");
  };

  return (
    <div>
      <h2>Enter Results</h2>
      <form onSubmit={handleSubmit}>
        <select onChange={e => setCompetitionId(e.target.value)} required>
          <option value="">Select competition</option>
          {competitions.map(c => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
        <input type="text" placeholder="Angler name" value={angler} onChange={e => setAngler(e.target.value)} required />
        <input type="number" placeholder="Fish weight (kg)" value={fishWeight} onChange={e => setFishWeight(e.target.value)} required />
        <button type="submit">Add Result</button>
      </form>
    </div>
  );
}