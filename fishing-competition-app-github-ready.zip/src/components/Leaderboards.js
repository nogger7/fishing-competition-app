import { getCompetitions, getResults } from "../utils/db";
import { generateLeaderboard } from "../utils/leaderboard";

export default function Leaderboards() {
  const competitions = getCompetitions();

  return (
    <div>
      <h2>Leaderboards</h2>
      {competitions.map(c => {
        const results = getResults(c.id);
        const leaderboard = generateLeaderboard(results);

        return (
          <div key={c.id}>
            <h3>{c.name}</h3>
            {leaderboard.length === 0 ? (
              <p>No results yet.</p>
            ) : (
              <ol>
                {leaderboard.map(l => (
                  <li key={l.angler}>{l.angler} — {l.totalWeight} kg ({l.points} pts)</li>
                ))}
              </ol>
            )}
          </div>
        );
      })}
    </div>
  );
}