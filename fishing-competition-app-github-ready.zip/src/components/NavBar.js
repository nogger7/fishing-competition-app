import { Link } from "react-router-dom";

export default function NavBar() {
  return (
    <nav style={{ padding: "1rem", background: "#1976d2", color: "#fff" }}>
      <Link to="/" style={{ marginRight: "1rem", color: "#fff" }}>Dashboard</Link>
      <Link to="/create" style={{ marginRight: "1rem", color: "#fff" }}>Create Competition</Link>
      <Link to="/enter" style={{ marginRight: "1rem", color: "#fff" }}>Enter Results</Link>
      <Link to="/upload" style={{ marginRight: "1rem", color: "#fff" }}>Upload Results</Link>
      <Link to="/leaderboards" style={{ color: "#fff" }}>Leaderboards</Link>
    </nav>
  );
}