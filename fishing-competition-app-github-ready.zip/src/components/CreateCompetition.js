import { useState } from "react";
import { createCompetition } from "../utils/db";

export default function CreateCompetition() {
  const [name, setName] = useState("");
  const [date, setDate] = useState("");

  const handleSubmit = e => {
    e.preventDefault();
    createCompetition({ name, date });
    setName("");
    setDate("");
    alert("Competition created!");
  };

  return (
    <div>
      <h2>Create Competition</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="Competition name" value={name} onChange={e => setName(e.target.value)} required />
        <input type="date" value={date} onChange={e => setDate(e.target.value)} required />
        <button type="submit">Create</button>
      </form>
    </div>
  );
}