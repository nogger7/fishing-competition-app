import { parseFile } from "../utils/fileHandlers";
import { addResult } from "../utils/db";

export default function UploadResults() {
  const handleFile = async e => {
    const file = e.target.files[0];
    if (!file) return;

    const results = await parseFile(file);
    results.forEach(r => addResult(r.competitionId, r));
    alert("Results uploaded!");
  };

  return (
    <div>
      <h2>Upload Results (CSV)</h2>
      <input type="file" accept=".csv" onChange={handleFile} />
    </div>
  );
}