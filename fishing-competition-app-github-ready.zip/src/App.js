import { BrowserRouter, Routes, Route } from "react-router-dom";
import NavBar from "./components/NavBar";
import CompetitionDashboard from "./components/CompetitionDashboard";
import CreateCompetition from "./components/CreateCompetition";
import EnterResults from "./components/EnterResults";
import UploadResults from "./components/UploadResults";
import Leaderboards from "./components/Leaderboards";

export default function App() {
  return (
    <BrowserRouter>
      <NavBar />
      <div style={{ padding: "1rem" }}>
        <Routes>
          <Route path="/" element={<CompetitionDashboard />} />
          <Route path="/create" element={<CreateCompetition />} />
          <Route path="/enter" element={<EnterResults />} />
          <Route path="/upload" element={<UploadResults />} />
          <Route path="/leaderboards" element={<Leaderboards />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}