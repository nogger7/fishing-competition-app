export function calculatePoints(weightKg) {
  let points = weightKg;
  if (weightKg >= 5) points += 2;
  if (weightKg >= 10) points += 5;
  return Math.round(points);
}