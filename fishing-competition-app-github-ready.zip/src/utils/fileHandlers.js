export async function parseFile(file) {
  const text = await file.text();
  const rows = text.split("\n").slice(1);
  return rows
    .filter(Boolean)
    .map(line => {
      const [competitionId, angler, fishWeight] = line.split(",");
      return { competitionId, angler, fishWeight: parseFloat(fishWeight) };
    });
}