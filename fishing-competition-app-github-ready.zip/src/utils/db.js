import { v4 as uuidv4 } from "uuid";

const LS_KEY = "fishing_app_data";

function loadData() {
  return JSON.parse(localStorage.getItem(LS_KEY) || '{"competitions":[],"results":{}}');
}

function saveData(data) {
  localStorage.setItem(LS_KEY, JSON.stringify(data));
}

export function getCompetitions() {
  return loadData().competitions;
}

export function createCompetition({ name, date }) {
  const data = loadData();
  const newComp = { id: uuidv4(), name, date };
  data.competitions.push(newComp);
  saveData(data);
}

export function addResult(competitionId, result) {
  const data = loadData();
  if (!data.results[competitionId]) data.results[competitionId] = [];
  data.results[competitionId].push(result);
  saveData(data);
}

export function getResults(competitionId) {
  return loadData().results[competitionId] || [];
}