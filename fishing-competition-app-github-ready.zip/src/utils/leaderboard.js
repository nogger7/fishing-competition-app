import { calculatePoints } from "./pointsCalculator";

export function generateLeaderboard(results) {
  const scores = {};

  results.forEach(r => {
    const pts = calculatePoints(r.fishWeight);
    if (!scores[r.angler]) scores[r.angler] = { angler: r.angler, totalWeight: 0, points: 0 };
    scores[r.angler].totalWeight += r.fishWeight;
    scores[r.angler].points += pts;
  });

  return Object.values(scores).sort((a, b) => b.points - a.points);
}